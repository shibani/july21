//
//  ViewController.h
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class View;
@interface ViewController : UIViewController {
    
    View *view;

    CADisplayLink *displayLink;
    
}

@end
