//
//  ViewController.m
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "View.h"


@implementation ViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Title";
        self.tabBarItem.image = [UIImage imageNamed: @"circle.png"];
        self.tabBarItem.badgeValue = @"1";

    }
    return self;
}

#pragma mark - View lifecycle


- (void)loadView
{
    CGRect f = [UIScreen mainScreen].applicationFrame;
    self.view = [[View alloc]initWithFrame: f];

}



- (void)viewDidLoad
{
    [super viewDidLoad];
    displayLink = [CADisplayLink displayLinkWithTarget: self.view
                                              selector: @selector(move:)
                   ];
    
	//Call move: every time the display is refreshed.
	[displayLink setFrameInterval: 1];
    
	NSRunLoop *loop = [NSRunLoop currentRunLoop];
	[displayLink addToRunLoop: loop forMode: NSDefaultRunLoopMode];

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if (interfaceOrientation == UIInterfaceOrientationPortrait
		|| interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
		return YES;
	} else {
		return NO;
	}}

#pragma mark - Memory management


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    NSRunLoop *loop = [NSRunLoop currentRunLoop];
	[displayLink removeFromRunLoop: loop forMode: NSDefaultRunLoopMode];
    [self.view release];
    [super dealloc];
}



@end
