//
//  vcAppDelegate.h
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TabBarController;
@interface vcAppDelegate : NSObject <UIApplicationDelegate> {
    
    UITabBarController *tabBarController;
    UIWindow *_window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
