//
//  View.h
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;
@interface View : UIView {
    
    ViewController *viewController;
   
    CGFloat dx;
    CGFloat dy;
    
    CGFloat ds;
    CGFloat dt;
    
    UIImageView *sphere;
    UIImageView *picture;

    
    int i;
    
}

//- (void) move: (CADisplayLink *) displayLink;
//- (void) bounce;
//- (void) doBounce;

@end
