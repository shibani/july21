//
//  main.m
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    int retVal = UIApplicationMain(argc, argv, nil, @"vcAppDelegate");
    [pool release];
    return retVal;
}
