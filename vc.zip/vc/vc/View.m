//
//  View.m
//  vc
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import <QuartzCore/QuartzCore.h>

@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blueColor];
        
		CGRect frame = CGRectMake(self.bounds.size.width/2, self.bounds.size.height/2, 20, 20);
        
        UIImage *image = [UIImage imageNamed:@"moon2"];
        sphere = [[UIImageView alloc] initWithImage: image];
        sphere.frame = frame;
        
        CGSize s = self.bounds.size;
    
        [self addSubview: sphere];
        
        
        //CGRect frame2 = CGRectMake(self.bounds.size.width, self.bounds.size.height, 0, 0);
        
        UIImage *image2 = [UIImage imageNamed:@"et"];
        picture = [[UIImageView alloc] initWithImage: image2];
        picture.center = CGPointMake(30, 380);
        
        [self addSubview: picture];
        
        
        i = 0;
        
        dx = 2;
        dy = 0;
        
        ds = 1;
        dt = -1.5;
    }
    return self;
}


- (void) move: (CADisplayLink *) displayLink {
    
    //NSLog(@"%.15g", displayLink.timestamp);	//15 significant digits
    
    picture.center = CGPointMake(picture.center.x + ds, picture.center.y + dt);
    [self doBounce];
    
    sphere.center = CGPointMake(sphere.center.x + dx, sphere.center.y + dy);
    [self bounce];

	[self setNeedsDisplay];    
}

- (void) bounce {	
    
    CGRect r = CGRectMake(-30, 0, self.bounds.size.width + 60, self.bounds.size.height);
    
    CGRect horizontal = sphere.frame;
    horizontal.origin.x += dx;
    
    
    CGRect vertical = sphere.frame;
    vertical.origin.y += dy;
    
    if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, r))) {
		dx = -dx;
	}
    
	if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, r))) {
		dy = -dy;
        
	}    
}
    
- (void) doBounce {	
    
    CGRect r = CGRectMake(-30, 0, self.bounds.size.width + 60, self.bounds.size.height + 100);
    
    CGRect horizontal = picture.frame;
    horizontal.origin.x += ds;
    
    
    CGRect vertical = picture.frame;
    vertical.origin.y += dt;
    
    if (!CGRectEqualToRect(horizontal, CGRectIntersection(horizontal, r))) {
        ds = -ds;
    }
    
    if (!CGRectEqualToRect(vertical, CGRectIntersection(vertical, r ))) {
         dt = -dt;       
    }     
} 


- (void)drawRect:(CGRect)rect {
    
    CGSize s = self.bounds.size;
    CGFloat width = s.width * 6/8;
    
    CGContextRef c = UIGraphicsGetCurrentContext();
    //center circle
    CGContextTranslateCTM(c, s.width / 2, s.height / 2); //move 0,0 to center
   
    //****moon drawing, do not delete
    CGMutablePathRef p = CGPathCreateMutable();   
    CGPathAddArc(p, NULL, 0, 0, width/2, 0, i/3 * M_PI/180, YES); 
    CGContextBeginPath(c); 
    CGContextAddPath(c, p);
    CGContextSetRGBFillColor(c, 1.0, 1.0, 0.8, 1.0);
    CGContextFillPath(c);  
    //****moon drawing, do not delete
    
    //****moving point do not delete
    CGMutablePathRef q = CGPathCreateMutable();
    CGContextBeginPath(c);
    CGPathAddArc(q, NULL, 0, 0, width/1.4, i * M_PI/630, (i-2) * M_PI/630, YES);
    CGContextAddPath(c, q);
    CGContextSetLineWidth(c, 2);
    CGContextSetRGBStrokeColor(c, 1, 1, 0, 1.0);
    CGContextStrokePath(c);  
    //****moving point do not delete
    
    
     ++i;
}



- (void)dealloc
{
    [super dealloc];
}

@end
