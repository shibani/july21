//
//  SecondView.h
//  vc
//
//  Created by Shibani Mookerjee on 7/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondView : UIView {
    
}

@end
