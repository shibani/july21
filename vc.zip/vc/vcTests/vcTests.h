//
//  vcTests.h
//  vcTests
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface vcTests : SenTestCase {
@private
    
}

@end
