//
//  vcTests.m
//  vcTests
//
//  Created by Shibani Mookerjee on 7/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "vcTests.h"


@implementation vcTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in vcTests");
}

@end
